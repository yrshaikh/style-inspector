# Style Inspector

Chrome plugin to identify colors and fonts used on websites and web pages